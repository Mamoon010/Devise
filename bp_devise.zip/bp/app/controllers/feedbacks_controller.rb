    class FeedbacksController < ApplicationController
        def create
          @book = Book.find(params[:book_id])
          @feedback = @book.feedbacks.create(feedback_params)

          redirect_to book_path(@book)
        end
      
        private
          def feedback_params
            params.require(:feedback).permit(:user, :body)
          end
      end
